#include "common.h"

#define SCIF0_BASE		0xe6e60000
#define SCIF1_BASE		0xe6e68000

#define SCIF_BASE		SCIF1_BASE
#define SCIF_BASE_PORT	PORT_SCIF

//UART INC===============================================================================
/*
 * Copy and modify from linux/drivers/serial/sh-sci.h
 */

struct uart_port {
	unsigned long	iobase;		/* in/out[bwl] */
	unsigned char	*membase;	/* read/write[bwl] */
	unsigned long	mapbase;	/* for ioremap */
	unsigned int	type;		/* port type */
};

#define PORT_SCI	52
#define PORT_SCIF	53
#define PORT_SCIFA	83
#define PORT_SCIFB	93

//#elif defined(CONFIG_R8A7790) || defined(CONFIG_R8A7791)
# define SCIF_ORER	0x0001
#if 1 // external clock
# define SCSCR_INIT(port)	0x32	/* TIE=0,RIE=0,TE=1,RE=1,REIE=0, */
#else
# define SCSCR_INIT(port)	0x31	/* TIE=0,RIE=0,TE=1,RE=1,REIE=0,CLK=input */
#endif
//#endif

/* SCSCR */
#define SCI_CTRL_FLAGS_TIE  0x80 /* all */
#define SCI_CTRL_FLAGS_RIE  0x40 /* all */
#define SCI_CTRL_FLAGS_TE   0x20 /* all */
#define SCI_CTRL_FLAGS_RE   0x10 /* all */
#define SCI_CTRL_FLAGS_REIE 0

/* SCxSR SCI */
#define SCI_TDRE  0x80 /* 7707 SCI, 7708 SCI, 7709 SCI, 7750 SCI */
#define SCI_RDRF  0x40 /* 7707 SCI, 7708 SCI, 7709 SCI, 7750 SCI */
#define SCI_ORER  0x20 /* 7707 SCI, 7708 SCI, 7709 SCI, 7750 SCI */
#define SCI_FER   0x10 /* 7707 SCI, 7708 SCI, 7709 SCI, 7750 SCI */
#define SCI_PER   0x08 /* 7707 SCI, 7708 SCI, 7709 SCI, 7750 SCI */
#define SCI_TEND  0x04 /* 7707 SCI, 7708 SCI, 7709 SCI, 7750 SCI */

#define SCI_ERRORS ( SCI_PER | SCI_FER | SCI_ORER)

/* SCxSR SCIF */
#define SCIF_ER    0x0080 /* 7705 SCIF, 7707 SCIF, 7709 SCIF, 7750 SCIF */
#define SCIF_TEND  0x0040 /* 7705 SCIF, 7707 SCIF, 7709 SCIF, 7750 SCIF */
#define SCIF_TDFE  0x0020 /* 7705 SCIF, 7707 SCIF, 7709 SCIF, 7750 SCIF */
#define SCIF_BRK   0x0010 /* 7705 SCIF, 7707 SCIF, 7709 SCIF, 7750 SCIF */
#define SCIF_FER   0x0008 /* 7705 SCIF, 7707 SCIF, 7709 SCIF, 7750 SCIF */
#define SCIF_PER   0x0004 /* 7705 SCIF, 7707 SCIF, 7709 SCIF, 7750 SCIF */
#define SCIF_RDF   0x0002 /* 7705 SCIF, 7707 SCIF, 7709 SCIF, 7750 SCIF */
#define SCIF_DR    0x0001 /* 7705 SCIF, 7707 SCIF, 7709 SCIF, 7750 SCIF */

//#elif defined(CONFIG_R8A7790) || defined(CONFIG_R8A7791)
# define SCIF_ERRORS (SCIF_PER | SCIF_FER | SCIF_ER | SCIF_BRK)
# define SCIF_RFDC_MASK	0x003f

//#endif

#ifndef SCIF_ORER
#define SCIF_ORER	0x0000
#endif

#define SCxSR_TEND(port)\
		(((port)->type == PORT_SCI) ? SCI_TEND	: SCIF_TEND)
#define SCxSR_ERRORS(port)\
		(((port)->type == PORT_SCI) ? SCI_ERRORS : SCIF_ERRORS)
#define SCxSR_RDxF(port)\
		(((port)->type == PORT_SCI) ? SCI_RDRF	: SCIF_RDF)
#define SCxSR_TDxE(port)\
		(((port)->type == PORT_SCI) ? SCI_TDRE	: SCIF_TDFE)
#define SCxSR_FER(port)\
		(((port)->type == PORT_SCI) ? SCI_FER	: SCIF_FER)
#define SCxSR_PER(port)\
		(((port)->type == PORT_SCI) ? SCI_PER	: SCIF_PER)
#define SCxSR_BRK(port)\
		((port)->type == PORT_SCI) ? 0x00		: SCIF_BRK)
#define SCxSR_ORER(port)\
		(((port)->type == PORT_SCI) ? SCI_ORER	: SCIF_ORER)


# define SCxSR_RDxF_CLEAR(port)	 (((port)->type == PORT_SCI) ? 0xbc : 0x00fc)
# define SCxSR_ERROR_CLEAR(port) (((port)->type == PORT_SCI) ? 0xc4 : 0x0073)
# define SCxSR_TDxE_CLEAR(port)  (((port)->type == PORT_SCI) ? 0x78 : 0x00df)
# define SCxSR_BREAK_CLEAR(port) (((port)->type == PORT_SCI) ? 0xc4 : 0x00e3)


/* SCFCR */
#define SCFCR_RFRST 0x0002
#define SCFCR_TFRST 0x0004
#define SCFCR_TCRST 0x4000
#define SCFCR_MCE   0x0008

#define SCI_MAJOR		204
#define SCI_MINOR_START		8

/* Generic serial flags */
#define SCI_RX_THROTTLE		0x0000001

#define SCI_MAGIC 0xbabeface

/*
 * Events are used to schedule things to happen at timer-interrupt
 * time, instead of at rs interrupt time.
 */
#define SCI_EVENT_WRITE_WAKEUP	0

#define SCI_IN(size, offset)\
	if ((size) == 8) {\
		return readb(port->membase + (offset));\
	} else {\
		return readw(port->membase + (offset));\
	}
#define SCI_OUT(size, offset, value)\
	if ((size) == 8) {\
		writeb(value, port->membase + (offset));\
	} else if ((size) == 16) {\
		writew(value, port->membase + (offset));\
	}

#define CPU_SCIx_FNS(name, sci_offset, sci_size, scif_offset, scif_size)\
	static inline unsigned int sci_##name##_in(struct uart_port *port) {\
		if (port->type == PORT_SCIF || port->type == PORT_SCIFB) {\
			SCI_IN(scif_size, scif_offset)\
		} else { /* PORT_SCI or PORT_SCIFA */\
			SCI_IN(sci_size, sci_offset);\
		}\
	}\
static inline void sci_##name##_out(struct uart_port *port,\
				unsigned int value) {\
	if (port->type == PORT_SCIF || port->type == PORT_SCIFB) {\
		SCI_OUT(scif_size, scif_offset, value)\
	} else {	/* PORT_SCI or PORT_SCIFA */\
		SCI_OUT(sci_size, sci_offset, value);\
	}\
}


#define CPU_SCIF_FNS(name, scif_offset, scif_size)			\
	static inline unsigned int sci_##name##_in(struct uart_port *port) {\
		SCI_IN(scif_size, scif_offset);\
	}\
	static inline void sci_##name##_out(struct uart_port *port,\
					unsigned int value) {\
		SCI_OUT(scif_size, scif_offset, value);\
	}

#define CPU_SCI_FNS(name, sci_offset, sci_size)\
	static inline unsigned int sci_##name##_in(struct uart_port *port) {\
		SCI_IN(sci_size, sci_offset);\
	}\
	static inline void sci_##name##_out(struct uart_port *port,\
					unsigned int value) {\
		SCI_OUT(sci_size, sci_offset, value);\
	}

#define SCIx_FNS(name, sh3_sci_offset, sh3_sci_size,\
				sh4_sci_offset, sh4_sci_size, \
				sh3_scif_offset, sh3_scif_size,\
				sh4_scif_offset, sh4_scif_size, \
				h8_sci_offset, h8_sci_size) \
	CPU_SCIx_FNS(name, sh4_sci_offset, sh4_sci_size,\
					sh4_scif_offset, sh4_scif_size)
#define SCIF_FNS(name, sh3_scif_offset, sh3_scif_size, \
				sh4_scif_offset, sh4_scif_size) \
	CPU_SCIF_FNS(name, sh4_scif_offset, sh4_scif_size)


/*      reg      SCI/SH3   SCI/SH4  SCIF/SH3   SCIF/SH4  SCI/H8*/
/*      name     off  sz   off  sz   off  sz   off  sz   off  sz*/
SCIx_FNS(SCSMR,  0x00,  8, 0x00,  8, 0x00,  8, 0x00, 16, 0x00,  8)
SCIx_FNS(SCBRR,  0x02,  8, 0x04,  8, 0x02,  8, 0x04,  8, 0x01,  8)
SCIx_FNS(SCSCR,  0x04,  8, 0x08,  8, 0x04,  8, 0x08, 16, 0x02,  8)
SCIx_FNS(SCxTDR, 0x06,  8, 0x0c,  8, 0x06,  8, 0x0C,  8, 0x03,  8)
SCIx_FNS(SCxSR,  0x08,  8, 0x10,  8, 0x08, 16, 0x10, 16, 0x04,  8)
SCIx_FNS(SCxRDR, 0x0a,  8, 0x14,  8, 0x0A,  8, 0x14,  8, 0x05,  8)
SCIF_FNS(SCFCR,                      0x0c,  8, 0x18, 16)
SCIF_FNS(SCFDR,                      0x0e, 16, 0x1C, 16)
SCIF_FNS(SCSPTR,                        0,  0, 0x20, 16)
//#if defined(CONFIG_R8A7790) || defined(CONFIG_R8A7791)
SCIF_FNS(DL,				0,  0, 0x30, 16)
SCIF_FNS(CKS,				0,  0, 0x34, 16)
//#endif
SCIF_FNS(SCLSR,                         0,  0, 0x24, 16)
#define sci_in(port, reg) sci_##reg##_in(port)
#define sci_out(port, reg, value) sci_##reg##_out(port, value)

#define DL_VALUE(bps, clk)	(clk / bps / 16)
#define SCBRR_VALUE(bps, clk) ((clk+16*bps)/(32*bps)-1)

static struct uart_port sh_sci = {
	.membase	= (unsigned char*)SCIF_BASE,
	.mapbase	= SCIF_BASE,
	.type		= SCIF_BASE_PORT,
};

void uart_init(unsigned int baseaddr, unsigned int baseport)
{
	// different setting in every board
	sh_sci.membase	= (unsigned char*)baseaddr;
	sh_sci.mapbase	= baseaddr;
	sh_sci.type		= baseport;
	
	sci_out(&sh_sci, SCSCR , 0x01);

	sci_out(&sh_sci, SCFCR, SCFCR_RFRST|SCFCR_TFRST);
	sci_in(&sh_sci, SCxSR);
	sci_out(&sh_sci, SCxSR, 0);
	sci_out(&sh_sci, SCSMR, 0);
	sci_out(&sh_sci, SCSMR, 0);
	sci_out(&sh_sci, SCSCR , 0x01);
#if 0 // internal clock
	//sci_out(&sh_sci, SCBRR, 0x34);
	//sci_out(&sh_sci, DL,    0x8D);
	sci_out(&sh_sci, SCBRR, SCBRR_VALUE(115200, 86666666));
	sci_out(&sh_sci, DL, 	DL_VALUE(115200, 86666666));
	sci_out(&sh_sci, CKS,	0x4000);
#else // extrenal clock
	sci_out(&sh_sci, DL, 	DL_VALUE(115200, 26000000));
#endif
	sci_out(&sh_sci, SCFCR, 0);
	sci_out(&sh_sci, SCSCR , SCSCR_INIT(&sh_sci));
	sci_out(&sh_sci, SCSCR , SCSCR_INIT(&sh_sci));
}


void serial_raw_putc(const char c)
{
	while (1) {
		/* Tx fifo is empty */
		if (sci_in(&sh_sci, SCxSR) & SCxSR_TEND(&sh_sci))
			break;
	}

	sci_out(&sh_sci, SCxTDR, c);
	sci_out(&sh_sci, SCxSR, sci_in(&sh_sci, SCxSR) & ~SCxSR_TEND(&sh_sci));
}

void uart_putc(const char c)
{
	if (c == '\n')
		serial_raw_putc('\r');
	serial_raw_putc(c);
}

void handle_error(void)
{
	sci_in(&sh_sci, SCxSR);
	sci_out(&sh_sci, SCxSR, SCxSR_ERROR_CLEAR(&sh_sci));
	sci_in(&sh_sci, SCLSR);
	sci_out(&sh_sci, SCLSR, 0x00);
}

int serial_getc_check(void)
{
	unsigned short status;

	status = sci_in(&sh_sci, SCxSR);

	if (status & SCIF_ERRORS)
		handle_error();
	if (sci_in(&sh_sci, SCLSR) & SCxSR_ORER(&sh_sci))
		handle_error();
	return status & (SCIF_DR | SCxSR_RDxF(&sh_sci));
}

char sh_serial_getc(void)
{
	unsigned short status;
	char ch;

	while (!serial_getc_check())
		;

	ch = sci_in(&sh_sci, SCxRDR);
	status = sci_in(&sh_sci, SCxSR);

	sci_out(&sh_sci, SCxSR, SCxSR_RDxF_CLEAR(&sh_sci));

	if (status & SCIF_ERRORS)
			handle_error();

	if (sci_in(&sh_sci, SCLSR) & SCxSR_ORER(&sh_sci))
		handle_error();
	return ch;
}
