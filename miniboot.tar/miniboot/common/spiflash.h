/*
 *	Suntec Platform 2016.05
 *	All Rights Reserved.
 *
 *  File description: Defines for renesas qspi operation
*/

/*interface function specifation*/
#include "common.h"

void QSPI_Initialize(void);
void QSPI_DeInitialize(void);
void QSPI_QuadRead_Flash(u32 addr, size_t len, void *buf, bool is4byte);
void QSPI_DMA_READ(u32 SrcAddr, u32 DestAddr, u32 Count);
void QSPI_Write_Flash(u32 addr, size_t len, void *buf);
void QSPI_BlockErase_Flash(u32 addr, size_t len);
void QSPI_SectorErase_Flash(u32 addr, size_t len);