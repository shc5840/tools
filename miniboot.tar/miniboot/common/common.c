#include <stdarg.h>
#include "common.h"

void* memcpy(void* pvTo, const void* pvFrom, size_t size)
{
	unsigned char* pbTo = (unsigned char*)pvTo;
	unsigned char* pbFrom = (unsigned char*)pvFrom;
	while(size-- > 0)
	{
		*pbTo++ = *pbFrom++;
	}
	return pvTo;
}

void *memset(void *src, int c, size_t n)
{
	unsigned char *p = (unsigned char*)src;
	if(NULL == src) return src;
	while(n > 0) {
		*p++ = (unsigned char)c;
		--n;
	}

	return src;
}

void udelay(u32 delay)
{
    u32 tmp = 10000;
    for(; delay>0; delay--){
        for(; tmp>0; tmp--){
            ;
        }
    }
}

void printch(char ch)
{
	uart_putc(ch);
}

void printdec(int dec)
{
	if(dec==0)
	{
		return;
	}
	printdec(dec/10);
	printch((char)(dec%10 + '0'));
}

void printstr(char* str)
{
	while(*str)
	{
		printch(*str++);
	}
}

void printbin(int bin)
{
	if(bin == 0)
	{
		printstr("0b");
		return;
	}
	printbin(bin/2);
	printch( (char)(bin%2 + '0'));
}

void printhex(unsigned int hex)
{
	if(hex==0)
	{
		printstr("0x");
		return;
	}

	printhex(hex/16);
	if(hex%16 < 10)
	{
		printch((char)(hex%16 + '0'));
	}
	else
	{
		printch((char)(hex%16 - 10 + 'a' ));
	}
}

void print(char* fmt, ...)
{
    int  vargint = 0;
    u32 varguint = 0;
    char* vargpch = NULL;
    char vargch = 0;
    char* pfmt = NULL;
    va_list vp;

    va_start(vp, fmt);
    pfmt = fmt;

    while(*pfmt)
    {
        if(*pfmt == '%')
        {
            switch(*(++pfmt))
            {

                case 'c':
                    vargch = va_arg(vp, int);
                    /*    va_arg(ap, type), if type is narrow type (char, short, float) an error is given in strict ANSI
                        mode, or a warning otherwise.In non-strict ANSI mode, 'type' is allowed to be any expression. */
                    if(0==vargch)
                    	uart_putc('0');
                    else
                    	printch(vargch);
                    break;
                case 'd':
                case 'i':
                    vargint = va_arg(vp, int);
                    if(0==vargint)
                    	uart_putc('0');
                    else
                    	printdec(vargint);
                    break;
                case 's':
                    vargpch = va_arg(vp, char*);
                    printstr(vargpch);
                    break;
                case 'b':
                case 'B':
                    vargint = va_arg(vp, int);
                    if(0==vargint)
                    	uart_putc('0');
                    else
                    	printbin(vargint);
                    break;
                case 'x':
                case 'X':
                    varguint = va_arg(vp, unsigned int);
                    if(0==varguint)
                    	uart_putc('0');
                    else
                    	printhex(varguint);
                    break;
                case '%':
                    printch('%');
                    break;
                default:
                    break;
            }
            pfmt++;
        }
        else
        {
            printch(*pfmt++);
        }
    }
    va_end(vp);
}

int raise (int signum)
{
    print("raise: Signal # %d caught\n", signum);
    return 0;
}
