/*
 *	Suntec Platform 2016.05
 *	All Rights Reserved.
 *
 *  File description: renesas qspi operation
*/

#include "spiflash.h"

/* Renesas QSPI Register Address */
#define SH_QSPI_BASE			0xE6B10000
#define SH_QSPI_SPCR			(SH_QSPI_BASE + 0x00)
#define SH_QSPI_SSLP			(SH_QSPI_BASE + 0x01)
#define SH_QSPI_SPPCR			(SH_QSPI_BASE + 0x02)
#define SH_QSPI_SPSR			(SH_QSPI_BASE + 0x03)
#define SH_QSPI_SPDR			(SH_QSPI_BASE + 0x04)
#define SH_QSPI_SPSCR			(SH_QSPI_BASE + 0x08)
#define SH_QSPI_SPSSR			(SH_QSPI_BASE + 0x09)
#define SH_QSPI_SPBR			(SH_QSPI_BASE + 0x0A)
#define SH_QSPI_SPDCR			(SH_QSPI_BASE + 0x0B)
#define SH_QSPI_SPCKD			(SH_QSPI_BASE + 0x0C)
#define SH_QSPI_SSLND			(SH_QSPI_BASE + 0x0D)
#define SH_QSPI_SPND			(SH_QSPI_BASE + 0x0E)
#define SH_QSPI_SPCMD0			(SH_QSPI_BASE + 0x10)
#define SH_QSPI_SPCMD1			(SH_QSPI_BASE + 0x12)
#define SH_QSPI_SPCMD2			(SH_QSPI_BASE + 0x14)
#define SH_QSPI_SPCMD3			(SH_QSPI_BASE + 0x16)
#define SH_QSPI_SPBFCR			(SH_QSPI_BASE + 0x18)
#define SH_QSPI_SPBDCR			(SH_QSPI_BASE + 0x1A)
#define SH_QSPI_SPBMUL0			(SH_QSPI_BASE + 0x1C)
#define SH_QSPI_SPBMUL1			(SH_QSPI_BASE + 0x20)
#define SH_QSPI_SPBMUL2			(SH_QSPI_BASE + 0x24)
#define SH_QSPI_SPBMUL3			(SH_QSPI_BASE + 0x28)

#define SH_QSPI_SPBDCR_RXBC		0x003f
#define SH_QSPI_SPBDCR_TXBC		0x3f00

/* S25FL132K and S25FL164K Command*/
#define CMD_SPIFLASH_READ_STATUS1		0x05
#define CMD_SPIFLASH_READ_STATUS2		0x35
#define CMD_SPIFLASH_READ_STATUS3		0x33
#define CMD_SPIFLASH_WRITE_ENABLE		0X06
#define CMD_SPIFLASH_WRITE_DISABLE		0X04
#define CMD_SPIFLASH_WRITE_STATUS		0x01
#define CMD_SPIFLASH_PROGRAM			0X02
#define CMD_SPIFLASH_SECTOR_ERASE4K		0X20
#define CMD_SPIFLASH_BLOCK_ERASE64K		0XD8
#define CMD_SPIFLASH_QUAD_READ			0x6B
#define CMD_SPIFLASH_QUADIO_READ		0xEB
#define CMD_SPIFLASH_JEDEC_ID 			0x9F

static void QSPI_Wait_TxEmpty(void)	//Wait transmit buffer (SPTXB) equal to or less than triggering number
{
	while(!(readb(SH_QSPI_SPSR) & BIT5));
}

static void QSPI_Wait_TEnd(void)	//Wait Transmit End
{
	while(!(readb(SH_QSPI_SPSR) & BIT6));
}

static void QSPI_Wait_RxFull(void)	//Wait receive buffer (SPRXB) equal to or greater than triggering number
{
	while(!(readb(SH_QSPI_SPSR) & BIT7));
}

static void QSPI_Wait_RXBC(void) // wait SPRXB receive data buffer not empty
{
	while(!(readw(SH_QSPI_SPBDCR) & SH_QSPI_SPBDCR_RXBC));
}

static void QSPI_Wait_TXBC(void) // wait SPTXB transmit data buffer empty
{
	while((readw(SH_QSPI_SPBDCR) & SH_QSPI_SPBDCR_TXBC));
}

static u8 QSPI_SingleMode8Bit(u8 wrData)
{
	QSPI_Wait_TxEmpty();
	writeb(wrData, SH_QSPI_SPDR);
	QSPI_Wait_RxFull();
	return readb(SH_QSPI_SPDR);
}

static void QSPI_WriteData8Bit(u8 wrdata)
{
	QSPI_Wait_TxEmpty();
	writeb(wrdata, SH_QSPI_SPDR);
}

static void QSPI_WriteData16Bit(u16 wrdata)
{
	QSPI_Wait_TxEmpty();
	writew(wrdata, SH_QSPI_SPDR);
}

static void QSPI_WriteData32Bit(u32 wrdata)
{
	QSPI_Wait_TxEmpty();
	writel(wrdata, SH_QSPI_SPDR);
}

static u8 QSPI_ReadData8Bit(void)
{
	QSPI_Wait_RxFull();
	return readb(SH_QSPI_SPDR);
}

static u16 QSPI_ReadData16Bit(void)
{
	QSPI_Wait_RxFull();
	return readw(SH_QSPI_SPDR);
}

static u32 QSPI_ReadData32Bit(void)
{
	QSPI_Wait_RxFull();
	return readl(SH_QSPI_SPDR);
}

static void QSPI_Read_FlashID(void)
{
	// setting for read flash id
	writeb(0x8,		SH_QSPI_SPCR);
	writew(0xe003,	SH_QSPI_SPCMD0);
	writel(0x4,		SH_QSPI_SPBMUL0);
	writeb(0xC0, 	SH_QSPI_SPBFCR);
	writeb(0x0, 	SH_QSPI_SPBFCR);
	writeb(0x0, 	SH_QSPI_SPSCR);		//CMD0
	writeb(0x48,	SH_QSPI_SPCR);

	QSPI_SingleMode8Bit(CMD_SPIFLASH_JEDEC_ID);
	print("QSPI:Manufacturer ID=%x,Device Type=%x,Capacity=%x\n",
		QSPI_SingleMode8Bit(0x00), QSPI_SingleMode8Bit(0x00), QSPI_SingleMode8Bit(0x00));
}

static u8 QSPI_Read_FlashStatus(u8 status_type)
{
	writeb(0x8,		SH_QSPI_SPCR);
	writew(0xe003,	SH_QSPI_SPCMD0);
	writel(2,		SH_QSPI_SPBMUL0);
	writeb(0xC0, 	SH_QSPI_SPBFCR);
	writeb(0x0, 	SH_QSPI_SPBFCR);
	writeb(0x0, 	SH_QSPI_SPSCR);
	writeb(0x48,	SH_QSPI_SPCR);

	QSPI_SingleMode8Bit(status_type);
	return QSPI_SingleMode8Bit(0x00);
}

static void QSPI_Write_Enable(void)
{
	writeb(0x8,		SH_QSPI_SPCR);
	writew(0xe003,	SH_QSPI_SPCMD0);
	writel(0x1,		SH_QSPI_SPBMUL0);
	writeb(0xC0, 	SH_QSPI_SPBFCR);
	writeb(0x0, 	SH_QSPI_SPBFCR);
	writeb(0x0, 	SH_QSPI_SPSCR);
	writeb(0x48,	SH_QSPI_SPCR);

	QSPI_SingleMode8Bit(CMD_SPIFLASH_WRITE_ENABLE);
}


void QSPI_QuadRead_Flash(u32 addr, size_t len, void *buf, bool is4byte)
{
	u32 i = 0;

	if (is4byte) {
		len = (len%4) ? (len/4 + 1) : (len/4);
	}

	if (!(QSPI_Read_FlashStatus(CMD_SPIFLASH_READ_STATUS2) & BIT1)) {
		print("Quad Mode Not Enabled, Please Set SR2 BIT1\n");
		return;
	}

	writeb(0x00,	SH_QSPI_SPBR);	//switch clock 97.5MHz

	writeb(0x8,		SH_QSPI_SPCR);
	writew(0xe083,	SH_QSPI_SPCMD0);
	writel(0x1,		SH_QSPI_SPBMUL0);	//CMD0 instruction 1Byte
	writew(0xe083,	SH_QSPI_SPCMD1);
	writel(0x3, 	SH_QSPI_SPBMUL1);	//CMD1 address 3Byte
	writew(0xe0d3,	SH_QSPI_SPCMD2);
	writel(0x4, 	SH_QSPI_SPBMUL2);	//CMD2 dummy 4Byte(8CLK) delay
	if (is4byte) {
		writew(0x0251,	SH_QSPI_SPCMD3);//CMD3 32bit quadspi read why only CPOL=0 CPHA=1 valid?
	} else {
		writew(0x0051,	SH_QSPI_SPCMD3);//CMD3  8bit quadspi read why only CPOL=0 CPHA=1 valid?
	}
	writel(len, 	SH_QSPI_SPBMUL3);
	writeb(0xC0, 	SH_QSPI_SPBFCR);
	writeb(0x0, 	SH_QSPI_SPBFCR);
	writeb(0x3, 	SH_QSPI_SPSCR);		//CMD0->CMD1->CMD2->CMD3
	writeb(0x48,	SH_QSPI_SPCR);

	QSPI_SingleMode8Bit(CMD_SPIFLASH_QUAD_READ);// send quad output command
	QSPI_SingleMode8Bit((addr>>16) & 0xFF);		// address A23-A16
	QSPI_SingleMode8Bit((addr>>8) & 0xFF);		// address A15-A08
	QSPI_SingleMode8Bit((addr>>0) & 0xFF);		// address A07-A00

	QSPI_ReadData8Bit();	// dummy
	QSPI_ReadData8Bit();	// dummy
	QSPI_ReadData8Bit();	// dummy
	QSPI_ReadData8Bit();	// dummy

	// read data
	for(i = 0; i < len; i++) {
		if (is4byte) {
			u32 val = QSPI_ReadData32Bit();
			*((u8*)buf++) = (val >> 24) & 0xff;
			*((u8*)buf++) = (val >> 16) & 0xff;
			*((u8*)buf++) = (val >> 8) & 0xff;
			*((u8*)buf++) = val & 0xff;
		}
		else {
			*((u8*)buf++) = QSPI_ReadData8Bit();
		}
	}

	writeb(0x01,	SH_QSPI_SPBR);	//switch clock 48.75MHz
}

void QSPI_Write_Flash(u32 addr, size_t len, void *buf)
{
	u32 byte_addr;
	u32 page_size;
	size_t chunk_len;
	size_t actual;
	u32 i = 0;

	page_size = 256;
	byte_addr = addr % page_size;

	for (actual = 0; actual < len; actual += chunk_len) {
		chunk_len = min(len - actual, page_size - byte_addr);
		byte_addr = 0;

		// Issue Write Enable command
		QSPI_Write_Enable();

		// Write the page programming command, address bytes and data
		writeb(0x8,		SH_QSPI_SPCR);
		writew(0xe083,	SH_QSPI_SPCMD0);	//CMD0 instruction 1Byte
		writel(0x1,		SH_QSPI_SPBMUL0);
		writew(0xe083,	SH_QSPI_SPCMD1);	//CMD1 address 3Byte
		writel(0x3, 	SH_QSPI_SPBMUL1);
		writew(0xe003,	SH_QSPI_SPCMD2);	//CMD2 8bit signle spi write
		writel(chunk_len, 	SH_QSPI_SPBMUL2);
		writeb(0xC0, 	SH_QSPI_SPBFCR);
		writeb(0x0, 	SH_QSPI_SPBFCR);
		writeb(0x2, 	SH_QSPI_SPSCR);		//CMD0->CMD1->CMD2
		writeb(0x48,	SH_QSPI_SPCR);

		QSPI_SingleMode8Bit(CMD_SPIFLASH_PROGRAM);	// program command
		QSPI_SingleMode8Bit(((addr + actual)>>16) & 0xFF);		// address A23-A16
		QSPI_SingleMode8Bit(((addr + actual)>>8) & 0xFF);		// address A15-A08
		QSPI_SingleMode8Bit(((addr + actual)>>0) & 0xFF);		// address A07-A00

		// write data
		for(i = 0; i < chunk_len; i++) {
			QSPI_SingleMode8Bit(*((u8*)buf++));
		}

		QSPI_Wait_TEnd();

		// Wait for operation completion
		while(QSPI_Read_FlashStatus(CMD_SPIFLASH_READ_STATUS1) & BIT1);
	}
}

void QSPI_BlockErase_Flash(u32 addr, size_t len)
{
	while (len > 0) {
		// Issue Write Enable command
		QSPI_Write_Enable();

		writeb(0x8,		SH_QSPI_SPCR);
		writew(0xe003,	SH_QSPI_SPCMD0);
		writel(0x4,		SH_QSPI_SPBMUL0);
		writeb(0xC0, 	SH_QSPI_SPBFCR);
		writeb(0x0, 	SH_QSPI_SPBFCR);
		writeb(0x0, 	SH_QSPI_SPSCR);		//CMD0
		writeb(0x48,	SH_QSPI_SPCR);

		QSPI_SingleMode8Bit(CMD_SPIFLASH_BLOCK_ERASE64K);	// block erase 64KB command
		QSPI_SingleMode8Bit((addr>>16) & 0xFF);		// address A23-A16
		QSPI_SingleMode8Bit((addr>>8) & 0xFF);		// address A15-A08
		QSPI_SingleMode8Bit((addr>>0) & 0xFF);		// address A07-A00

		// Assign next sector values
		addr += 0x10000;
		len -= 0x10000;

		// Wait for operation completion
		while(QSPI_Read_FlashStatus(CMD_SPIFLASH_READ_STATUS1) & BIT1);
	}
}

void QSPI_SectorErase_Flash(u32 addr, size_t len)
{
	while (len > 0) {
		// Issue Write Enable command
		QSPI_Write_Enable();

		writeb(0x8,		SH_QSPI_SPCR);
		writew(0xe003,	SH_QSPI_SPCMD0);
		writel(0x4,		SH_QSPI_SPBMUL0);
		writeb(0xC0, 	SH_QSPI_SPBFCR);
		writeb(0x0, 	SH_QSPI_SPBFCR);
		writeb(0x0, 	SH_QSPI_SPSCR);		//CMD0
		writeb(0x48,	SH_QSPI_SPCR);

		QSPI_SingleMode8Bit(CMD_SPIFLASH_SECTOR_ERASE4K);	// block erase 4KB command
		QSPI_SingleMode8Bit((addr>>16) & 0xFF);		// address A23-A16
		QSPI_SingleMode8Bit((addr>>8) & 0xFF);		// address A15-A08
		QSPI_SingleMode8Bit((addr>>0) & 0xFF);		// address A07-A00

		// Assign next sector values
		addr += 0x1000;
		len -= 0x1000;

		// Wait for operation completion
		while(QSPI_Read_FlashStatus(CMD_SPIFLASH_READ_STATUS1) & BIT1);
	}
}


#define	SYSDMAC0_BASE			0xE6700000U
#define	SYSDMAC1_BASE			0xE6720000U
#define	SYSDMAC_DMAISTA_L		(SYSDMAC0_BASE + 0x0020U)
#define SYSDMAC_DMASEC_L		(SYSDMAC0_BASE + 0x0030U)
#define SYSDMAC_DMAOR_L			(SYSDMAC0_BASE + 0x0060U)
#define SYSDMAC_DMACHCLR_L		(SYSDMAC0_BASE + 0x0080U)
#define SYSDMAC_DMADPSEC_L		(SYSDMAC0_BASE + 0x00A0U)

#define SYSDMAC_DMASAR_01		(SYSDMAC0_BASE + 0x8080U)
#define SYSDMAC_DMADAR_01		(SYSDMAC0_BASE + 0x8084U)
#define SYSDMAC_DMATCR_01		(SYSDMAC0_BASE + 0x8088U)
#define SYSDMAC_DMATSR_01		(SYSDMAC0_BASE + 0x80A8U)
#define SYSDMAC_DMACHCR_01		(SYSDMAC0_BASE + 0x808CU)
#define SYSDMAC_DMATCRB_01		(SYSDMAC0_BASE + 0x8098U)
#define SYSDMAC_DMATSRB_01		(SYSDMAC0_BASE + 0x80B8U)

#define SYSDMAC_DMACHCRB_01		(SYSDMAC0_BASE + 0x809CU)
#define SYSDMAC_DMARS_01		(SYSDMAC0_BASE + 0x80C0U)
#define SYSDMAC_DMABUFCR_01		(SYSDMAC0_BASE + 0x80C8U)
#define SYSDMAC_DMADPBASE_01	(SYSDMAC0_BASE + 0x80D0U)
#define SYSDMAC_DMADPCR_01		(SYSDMAC0_BASE + 0x80D4U)
#define SYSDMAC_DMAFIXDPBASE_01	(SYSDMAC0_BASE + 0x80E0U)
#define SYSDMAC_DMAFIXSAR_01	(SYSDMAC0_BASE + 0x8090U)
#define SYSDMAC_DMAFIXDAR_01	(SYSDMAC0_BASE + 0x8094U)
static long WaitDma01(void)
{
	u32 status = 0;

	while(1) {
		status = readl(SYSDMAC_DMACHCR_01);
		if(status & BIT1) {
			writel((readl(SYSDMAC_DMACHCR_01) & ~BIT1), SYSDMAC_DMACHCR_01);	// TE Clear
			break;
		}
		if(status & BIT31) {
			writel((readl(SYSDMAC_DMACHCR_01) & ~BIT31), SYSDMAC_DMACHCR_01);	// CAE Clear
			return 1;
		}
	}
	writew(0, SYSDMAC_DMAOR_L);		// CH0 > CH1 > ... > CH13 > CH14 disable
	return 0;
}
void QSPI_DMA_READ(u32 SrcAddr, u32 DestAddr, u32 Count)
{
	Count = (Count%4) ? (Count/4 + 1) : (Count/4);

    writeb(0x00,	SH_QSPI_SPBR);		//switch clock 97.5MHz

	writel((readl(SYSDMAC_DMACHCR_01) & 0x00004800), SYSDMAC_DMACHCR_01);	// disable dma_channel_01
	writel(0x18, SYSDMAC_DMARS_01);				// DMA Extended Resource Selectors QSPI
	writel(SH_QSPI_SPDR, SYSDMAC_DMASAR_01);	// Source Address
	writel(DestAddr, SYSDMAC_DMADAR_01);		// Destination Address
	writel(8, SYSDMAC_DMATCR_01);				// Transfer count(command 1Byte + address 3Byte + dummy clk 4Byte)

	// channel control DM[1:0]=01(Destination addresses are incremented)
	// SM[1:0]=0(Source address is fixed)
	// RS[3:0]=1000(Source is selected by the DMA extended resource selector)
	// DMA Enable
	writel((readl(SYSDMAC_DMACHCR_01) | 0x00004801), SYSDMAC_DMACHCR_01);

	writew(0x0001, SYSDMAC_DMAOR_L);	// CH0 > CH1 > ... > CH13 > CH14 enable,start

	writeb(CMD_SPIFLASH_QUAD_READ, SH_QSPI_SPDR);// send quad output command
	writeb((u8)((SrcAddr>>16) & 0xFF), SH_QSPI_SPDR);	// address A23-A16
	writeb((u8)((SrcAddr>>8) & 0xFF), SH_QSPI_SPDR);	// address A15-A08
	writeb((u8)((SrcAddr>>0) & 0xFF), SH_QSPI_SPDR);	// address A07-A00

	writeb(0x3, 	SH_QSPI_SPSCR);		//CMD0->CMD1->CMD2->CMD3
	writew(0xe083,	SH_QSPI_SPCMD0);
	writel(0x1,		SH_QSPI_SPBMUL0);	//CMD0 instruction 1Byte
	writew(0xe083,	SH_QSPI_SPCMD1);
	writel(0x3, 	SH_QSPI_SPBMUL1);	//CMD1 address 3Byte
	writew(0xe0d3,	SH_QSPI_SPCMD2);
	writel(0x4, 	SH_QSPI_SPBMUL2);	//CMD2 dummy 4Byte(8CLK) delay
	writew(0x0251,	SH_QSPI_SPCMD3);	//CMD3 32bit quadspi read why only CPOL=0 CPHA=1 valid?
	writel(Count,	SH_QSPI_SPBMUL3);

	writeb(0xcb,	SH_QSPI_SPCR);

	// wait command address dummy transfer end
	if(WaitDma01()) {
		while(1){}
	}

	writel((readl(SYSDMAC_DMACHCR_01) & 0x00004800), SYSDMAC_DMACHCR_01);	// disable dma_channel_01
	writel(DestAddr, SYSDMAC_DMADAR_01);	// Destination Address
	writel(Count, 	SYSDMAC_DMATCR_01);		// Transfer count(data part, 32bit mode)
	writel((readl(SYSDMAC_DMACHCR_01) | 0x00004801 | BIT4), SYSDMAC_DMACHCR_01); // DMA Enable and DMA Transfer Size(4Byte)

	writew(0x0001, SYSDMAC_DMAOR_L);	// CH0 > CH1 > ... > CH13 > CH14 enable,start

	// wait data part transfer end
	if(WaitDma01()) {
		while(1){}
	}

	writeb(0x8,	    SH_QSPI_SPCR);
	writeb(0xc0,    SH_QSPI_SPBFCR);
	writeb(0x00,    SH_QSPI_SPBFCR);
	writeb(0x01,	SH_QSPI_SPBR);		//switch clock 48.75MHz

	writel((readl(SYSDMAC_DMACHCR_01) & 0x00004800), SYSDMAC_DMACHCR_01);	// disable dma_channel_01
	writel((readl(SYSDMAC_DMACHCLR_L) | BIT1), SYSDMAC_DMACHCLR_L);		// clear dma_channel_01
}

void QSPI_Initialize(void)
{
	writeb(0x08,	SH_QSPI_SPCR);		// disable spi function
	writeb(0x00,	SH_QSPI_SSLP);		// set SSL signal level
	writeb(0x06,	SH_QSPI_SPPCR);		// set MOSI signal value when transfer is in idle state
	writeb(0x01,	SH_QSPI_SPBR);		// SPBR[7:0]=1 SPCMD:BRDV[1:0]=0 QSPICLK=48.75Mbps, S25FL132K_164K_00 ordinary read speed restrict
	writeb(0x00,	SH_QSPI_SPDCR);     // disable dummy data transmission
	writeb(0x00,	SH_QSPI_SPCKD);		// <When SPCMD.SCKDEN=1 1.5QSPCLK>
	writeb(0x00,	SH_QSPI_SSLND);		// <When SPCMD.SLNDEN=1 1QSPCLK>
	writeb(0x00,	SH_QSPI_SPND);		// <When SPCMD.SPNDEN=1 1QSPCLK>
	writeb(0xc0,    SH_QSPI_SPBFCR);
	writeb(0x00,    SH_QSPI_SPBFCR);    // clear buffer

#if 0
	QSPI_Read_FlashID();
#endif
}

void QSPI_DeInitialize(void)
{
	writeb(0x8,	    SH_QSPI_SPCR);      // disable spi function
	writeb(0xc0,    SH_QSPI_SPBFCR);
	writeb(0x00,    SH_QSPI_SPBFCR);    // clear buffer
}