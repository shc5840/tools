#include "../common/common.h"
#include "../common/spiflash.h"
#include "../common/s_record.h"

//REG ADDR===============================================================================
#define	RWDT_BASE				0xE6020000
#define RWTCSRA					(RWDT_BASE + 0x4)

#define	SWDT_BASE				0xE6030000
#define SWTCSRA					(SWDT_BASE + 0x4)

#define PFC_BASE                0xE6060000
#define PFC_PMMR                PFC_BASE + 0
#define PFC_GPSR0               PFC_BASE + 0x4
#define PFC_GPSR1               PFC_BASE + 0x8
#define PFC_GPSR2               PFC_BASE + 0xC
#define PFC_GPSR3               PFC_BASE + 0x10
#define PFC_GPSR4               PFC_BASE + 0x14
#define PFC_GPSR5               PFC_BASE + 0x18
#define PFC_GPSR6               PFC_BASE + 0x1C
#define PFC_GPSR7               PFC_BASE + 0x74
#define PFC_IPSR0               PFC_BASE + 0x20
#define PFC_IPSR1               PFC_BASE + 0x24
#define PFC_IPSR2               PFC_BASE + 0x28
#define PFC_IPSR3               PFC_BASE + 0x2C
#define PFC_IPSR4               PFC_BASE + 0x30
#define PFC_IPSR5               PFC_BASE + 0x34
#define PFC_IPSR6               PFC_BASE + 0x38
#define PFC_IPSR7               PFC_BASE + 0x3C
#define PFC_IPSR8               PFC_BASE + 0x40
#define PFC_IPSR9               PFC_BASE + 0x44
#define PFC_IPSR10              PFC_BASE + 0x48
#define PFC_IPSR11              PFC_BASE + 0x4C
#define PFC_IPSR12              PFC_BASE + 0x50
#define PFC_IPSR13              PFC_BASE + 0x54
#define PFC_IPSR14              PFC_BASE + 0x58
#define PFC_IPSR15              PFC_BASE + 0x5C
#define PFC_IPSR16              PFC_BASE + 0x160
#define PFC_MOD_SEL             PFC_BASE + 0x90
#define PFC_MOD_SEL2            PFC_BASE + 0x94
#define PFC_MOD_SEL3            PFC_BASE + 0x98
#define PFC_MOD_SEL4            PFC_BASE + 0x9C
#define PFC_PUPR0               PFC_BASE + 0x100
#define PFC_PUPR1               PFC_BASE + 0x104
#define PFC_PUPR2               PFC_BASE + 0x108
#define PFC_PUPR3               PFC_BASE + 0x10C
#define PFC_PUPR4               PFC_BASE + 0x110
#define PFC_PUPR5               PFC_BASE + 0x114
#define PFC_PUPR6               PFC_BASE + 0x118
#define PFC_PUPR7               PFC_BASE + 0x11C
#define PFC_IOCTRL0             PFC_BASE + 0x60
#define PFC_IOCTRL1             PFC_BASE + 0x64
#define PFC_IOCTRL2             PFC_BASE + 0x68
#define PFC_IOCTRL3             PFC_BASE + 0x6C
#define PFC_IOCTRL4             PFC_BASE + 0x84
#define PFC_IOCTRL5             PFC_BASE + 0x88
#define PFC_IOCTRL6             PFC_BASE + 0x8C
#define PFC_IOCTRL7             PFC_BASE + 0x70

#define GPIO_BASE               0xE6050000
#define GPIO_0_BASE             (GPIO_BASE + 0x0)
#define GPIO_1_BASE             (GPIO_BASE + 0x1000)
#define GPIO_2_BASE             (GPIO_BASE + 0x2000)
#define GPIO_3_BASE             (GPIO_BASE + 0x3000)
#define GPIO_4_BASE             (GPIO_BASE + 0x4000)
#define GPIO_5_BASE             (GPIO_BASE + 0x5000)
#define GPIO_6_BASE             (GPIO_BASE + 0x5400)
#define GPIO_7_BASE             (GPIO_BASE + 0x5800)
#define GPIO_IOINTSEL(pfx)      (GPIO_##pfx##_BASE + 0x0)
#define GPIO_INOUTSEL(pfx)      (GPIO_##pfx##_BASE + 0x4)
#define GPIO_OUTDT(pfx)         (GPIO_##pfx##_BASE + 0x8)
#define GPIO_POSNEG(pfx)        (GPIO_##pfx##_BASE + 0x20)

//#------------------------------------------------------------------------------
//# LBSC
//# R-CarM2_01_16_LBSC_0010_e.pdf
#define	LBSC_CS0CTRL		0xFEC00200	//# Area 0 control register
#define	LBSC_CS1CTRL		0xFEC00204	//# Area 1 control register
#define	LBSC_ECS0CTRL		0xFEC00208	//# Expansion area 0 control register
#define	LBSC_ECS1CTRL		0xFEC0020C	//# Expansion area 1 control register
#define	LBSC_ECS2CTRL		0xFEC00210	//# Expansion area 2 control register
#define	LBSC_ECS3CTRL		0xFEC00214	//# Expansion area 3 control register
#define	LBSC_ECS4CTRL		0xFEC00218	//# Expansion area 4 control register
#define	LBSC_ECS5CTRL		0xFEC0021C	//# Expansion area 5 control register
#define	LBSC_CSWCR0			0xFEC00230	//# Area 0 RD/WE pulse control register
#define	LBSC_CSWCR1			0xFEC00234	//# Area 1 RD/WE pulse control register
#define	LBSC_ECSWCR0		0xFEC00238	//# Expansion area 0 RD/WE pulse control register
#define	LBSC_ECSWCR1		0xFEC0023C	//# Expansion area 1 RD/WE pulse control register
#define	LBSC_ECSWCR2		0xFEC00240	//# Expansion area 2 RD/WE pulse control register
#define	LBSC_ECSWCR3		0xFEC00244	//# Expansion area 3 RD/WE pulse control register
#define	LBSC_ECSWCR4		0xFEC00248	//# Expansion area 4 RD/WE pulse control register
#define	LBSC_ECSWCR5		0xFEC0024C	//# Expansion area 5 RD/WE pulse control register
#define	LBSC_EXDMAWCR0		0xFEC00250	//# LBSC-DMAC channel 0 RD/WE pulse control register
#define	LBSC_EXDMAWCR1		0xFEC00254	//# LBSC-DMAC channel 1 RD/WE pulse control register
#define	LBSC_EXDMAWCR2		0xFEC00258	//# LBSC-DMAC channel 2 RD/WE pulse control register
#define	LBSC_CSPWCR0		0xFEC00280	//# Area 0 external wait control register
#define	LBSC_CSPWCR1		0xFEC00284	//# Area 1 external wait control register
#define	LBSC_ECSPWCR0		0xFEC00288	//# Expansion area 0 external wait control register
#define	LBSC_ECSPWCR1		0xFEC0028C	//# Expansion area 1 external wait control register
#define	LBSC_ECSPWCR2		0xFEC00290	//# Expansion area 2 external wait control register
#define	LBSC_ECSPWCR3		0xFEC00294	//# Expansion area 3 external wait control register
#define	LBSC_ECSPWCR4		0xFEC00298	//# Expansion area 4 external wait control register
#define	LBSC_ECSPWCR5		0xFEC0029C	//# Expansion area 5 external wait control register
#define	LBSC_EXWTSYNC		0xFEC002A0	//# External wait input control register
#define	LBSC_CS0BSTCTL		0xFEC002B0	//# Area 0 burst control register
#define	LBSC_CS0BTPH		0xFEC002B4	//# Area 0 burst pitch set register
#define	LBSC_CS1GDST		0xFEC002C0	//# Area 1 guard setting register
#define	LBSC_ECS0GDST		0xFEC002C4	//# Expansion area 0 guard setting register
#define	LBSC_ECS1GDST		0xFEC002C8	//# Expansion area 1 guard setting register
#define	LBSC_ECS2GDST		0xFEC002CC	//# Expansion area 2 guard setting register
#define	LBSC_ECS3GDST		0xFEC002D0	//# Expansion area 3 guard setting register
#define	LBSC_ECS4GDST		0xFEC002D4	//# Expansion area 4 guard setting register
#define	LBSC_ECS5GDST		0xFEC002D8	//# Expansion area 5 guard setting register
#define	LBSC_EXDMASET0		0xFEC002F0	//# LBSC-DMAC channel 0 area allocation register
#define	LBSC_EXDMASET1		0xFEC002F4	//# LBSC-DMAC channel 1 area allocation register
#define	LBSC_EXDMASET2		0xFEC002F8	//# LBSC-DMAC channel 2 area allocation register
#define	LBSC_EXDMCR0		0xFEC00310	//# LBSC-DMAC channel 0 control register
#define	LBSC_EXDMCR1		0xFEC00314	//# LBSC-DMAC channel 1 control register
#define	LBSC_EXDMCR2		0xFEC00318	//# LBSC-DMAC channel 2 control register
#define	LBSC_BCINTSR		0xFEC00330	//# BSC interrupt source status register
#define	LBSC_BCINTCR		0xFEC00334	//# BSC interrupt source clear register
#define	LBSC_BCINTMR		0xFEC00338	//# BSC interrupt enable register
#define	LBSC_EXBATLV		0xFEC00340	//# EX-BUS priority level set register
#define	LBSC_EXWTSTS		0xFEC00344	//# External wait status register
#define	LBSC_ATACSCTRL		0xFEC00380	//# ATACS control register
#define	LBSC_EXBCT			0xFEC003C0	//# EX-BUS wait timeout detection base counter register
#define	LBSC_EXTCT			0xFEC003C4	//# EX-BUS wait timeout detection counter register
#define	LBSC_EXTSR			0xFEC00010	//# EX-BUS wait timeout detection access source indication register
#define	LBSC_EXTADR			0xFEC00014	//# EX-BUS wait timeout detection address indication register




#define DBSC3_0_BASE			0xE6790000
#define DBSC3_1_BASE			0xE67A0000
#define DBSC3_0_DBACEN			(DBSC3_0_BASE + 0x10)
#define DBSC3_1_DBACEN			(DBSC3_1_BASE + 0x10)
#define DBSC3_0_DBRFEN			(DBSC3_0_BASE + 0x14)
#define DBSC3_1_DBRFEN			(DBSC3_1_BASE + 0x14)
#define DBSC3_0_DBCMD			(DBSC3_0_BASE + 0x18)
#define DBSC3_1_DBCMD			(DBSC3_1_BASE + 0x18)
#define DBSC3_0_DBKIND			(DBSC3_0_BASE + 0x20)
#define DBSC3_1_DBKIND			(DBSC3_1_BASE + 0x20)
#define DBSC3_0_DBCONF0			(DBSC3_0_BASE + 0x24)
#define DBSC3_1_DBCONF0			(DBSC3_1_BASE + 0x24)
#define DBSC3_0_PHYT			(DBSC3_0_BASE + 0x30)
#define DBSC3_1_PHYT			(DBSC3_1_BASE + 0x30)
#define DBSC3_0_DBTR0			(DBSC3_0_BASE + 0x40)
#define DBSC3_1_DBTR0			(DBSC3_1_BASE + 0x40)
#define DBSC3_0_DBTR1			(DBSC3_0_BASE + 0x44)
#define DBSC3_1_DBTR1			(DBSC3_1_BASE + 0x44)
#define DBSC3_0_DBTR2			(DBSC3_0_BASE + 0x48)
#define DBSC3_1_DBTR2			(DBSC3_1_BASE + 0x48)
#define DBSC3_0_DBTR3			(DBSC3_0_BASE + 0x50)
#define DBSC3_1_DBTR3			(DBSC3_1_BASE + 0x50)
#define DBSC3_0_DBTR4			(DBSC3_0_BASE + 0x54)
#define DBSC3_1_DBTR4			(DBSC3_1_BASE + 0x54)
#define DBSC3_0_DBTR5			(DBSC3_0_BASE + 0x58)
#define DBSC3_1_DBTR5			(DBSC3_1_BASE + 0x58)
#define DBSC3_0_DBTR6			(DBSC3_0_BASE + 0x5C)
#define DBSC3_1_DBTR6			(DBSC3_1_BASE + 0x5C)
#define DBSC3_0_DBTR7			(DBSC3_0_BASE + 0x60)
#define DBSC3_1_DBTR7			(DBSC3_1_BASE + 0x60)
#define DBSC3_0_DBTR8			(DBSC3_0_BASE + 0x64)
#define DBSC3_1_DBTR8			(DBSC3_1_BASE + 0x64)
#define DBSC3_0_DBTR9			(DBSC3_0_BASE + 0x68)
#define DBSC3_1_DBTR9			(DBSC3_1_BASE + 0x68)
#define DBSC3_0_DBTR10			(DBSC3_0_BASE + 0x6C)
#define DBSC3_1_DBTR10			(DBSC3_1_BASE + 0x6C)
#define DBSC3_0_DBTR11			(DBSC3_0_BASE + 0x70)
#define DBSC3_1_DBTR11			(DBSC3_1_BASE + 0x70)
#define DBSC3_0_DBTR12			(DBSC3_0_BASE + 0x74)
#define DBSC3_1_DBTR12			(DBSC3_1_BASE + 0x74)
#define DBSC3_0_DBTR13			(DBSC3_0_BASE + 0x78)
#define DBSC3_1_DBTR13			(DBSC3_1_BASE + 0x78)
#define DBSC3_0_DBTR14			(DBSC3_0_BASE + 0x7C)
#define DBSC3_1_DBTR14			(DBSC3_1_BASE + 0x7C)
#define DBSC3_0_DBTR15			(DBSC3_0_BASE + 0x80)
#define DBSC3_1_DBTR15			(DBSC3_1_BASE + 0x80)
#define DBSC3_0_DBTR16			(DBSC3_0_BASE + 0x84)
#define DBSC3_1_DBTR16			(DBSC3_1_BASE + 0x84)
#define DBSC3_0_DBTR17			(DBSC3_0_BASE + 0x88)
#define DBSC3_1_DBTR17			(DBSC3_1_BASE + 0x88)
#define DBSC3_0_DBTR18			(DBSC3_0_BASE + 0x8C)
#define DBSC3_1_DBTR18			(DBSC3_1_BASE + 0x8C)
#define DBSC3_0_DBTR19			(DBSC3_0_BASE + 0x90)
#define DBSC3_1_DBTR19			(DBSC3_1_BASE + 0x90)
#define DBSC3_0_DBBL			(DBSC3_0_BASE + 0xB0)
#define DBSC3_1_DBBL			(DBSC3_1_BASE + 0xB0)
#define DBSC3_0_DBADJ0			(DBSC3_0_BASE + 0xC0)
#define DBSC3_1_DBADJ0			(DBSC3_1_BASE + 0xC0)
#define DBSC3_0_DBADJ2			(DBSC3_0_BASE + 0xC8)
#define DBSC3_1_DBADJ2			(DBSC3_1_BASE + 0xC8)
#define DBSC3_0_DBRFCNF0		(DBSC3_0_BASE + 0xE0)
#define DBSC3_1_DBRFCNF0		(DBSC3_1_BASE + 0xE0)
#define DBSC3_0_DBRFCNF1		(DBSC3_0_BASE + 0xE4)
#define DBSC3_1_DBRFCNF1		(DBSC3_1_BASE + 0xE4)
#define DBSC3_0_DBRFCNF2		(DBSC3_0_BASE + 0xE8)
#define DBSC3_1_DBRFCNF2		(DBSC3_1_BASE + 0xE8)
#define DBSC3_0_DBCALCNF		(DBSC3_0_BASE + 0xF4)
#define DBSC3_1_DBCALCNF		(DBSC3_1_BASE + 0xF4)
#define DBSC3_0_DBCALTR			(DBSC3_0_BASE + 0xF8)
#define DBSC3_1_DBCALTR			(DBSC3_1_BASE + 0xF8)
#define DBSC3_0_DBRNK0			(DBSC3_0_BASE + 0x100)
#define DBSC3_1_DBRNK0			(DBSC3_1_BASE + 0x100)
#define DBSC3_0_DBDFISTAT		(DBSC3_0_BASE + 0x240)
#define DBSC3_1_DBDFISTAT		(DBSC3_1_BASE + 0x240)
#define DBSC3_0_DBDFICNT		(DBSC3_0_BASE + 0x244)
#define DBSC3_1_DBDFICNT		(DBSC3_1_BASE + 0x244)
#define DBSC3_0_DBPDLCK			(DBSC3_0_BASE + 0x280)
#define DBSC3_1_DBPDLCK			(DBSC3_1_BASE + 0x280)
#define DBSC3_0_DBPDRGA			(DBSC3_0_BASE + 0x290)
#define DBSC3_1_DBPDRGA			(DBSC3_1_BASE + 0x290)
#define DBSC3_0_DBPDRGD			(DBSC3_0_BASE + 0x2A0)
#define DBSC3_1_DBPDRGD			(DBSC3_1_BASE + 0x2A0)
#define DBSC3_0_DBBS0CNT1		(DBSC3_0_BASE + 0x304)
#define DBSC3_1_DBBS0CNT1		(DBSC3_1_BASE + 0x304)
#define DBSC3_0_DBWT0CNF0		(DBSC3_0_BASE + 0x380)
#define DBSC3_1_DBWT0CNF0		(DBSC3_1_BASE + 0x380)
#define DBSC3_0_DBWT0CNF4		(DBSC3_0_BASE + 0x390)
#define DBSC3_1_DBWT0CNF4		(DBSC3_1_BASE + 0x390)


#define	MSTPSR1					0xE6150038
#define	SMSTPCR1				0xE6150134
#define TMU0_MSTP125			(1 << 25)

#define MSTPSR3					0xE6150048
#define SMSTPCR3				0xE615011C
#define MMC0_MSTP315			(1 << 15)
#define SDHI0_MSTP314			(1 << 14)
#define SDHI1_MSTP312			(1 << 12)
#define SDHI2_MSTP311			(1 << 11)

#define	MSTPSR7					0xE61501C4
#define	SMSTPCR7				0xE615014C
#define SCIF0_MSTP721			(1 << 21)
#define SCIF1_MSTP720			(1 << 20)

#define	MSTPSR8					0xE61509A0
#define	SMSTPCR8				0xE6150990
#define ETHER_MSTP813			(1 << 13)

#define	MSTPSR9					0xE61509A4
#define	SMSTPCR9				0xE6150994
#define	QSPI_MSTP917			(1 << 17)
