#include "board.h"

void wtd_init(void)
{
	/* RWDT,secureWDT setting (Timer Disable setting) */
	writel(0xA5A5A500, RWTCSRA);
	writel(0xA5A5A500, SWTCSRA);
}

#define	SetGuardREG_back(addr, mask, value)		\
{ \
	u32	val; \
	val = (readl(addr) & ~(mask)) | (value);	\
	writel(~val, PFC_PMMR); \
	writel(val, addr); \
}

#define	SetGuardREG(addr, value)		\
{ \
	writel(~value, PFC_PMMR); \
	writel(value, addr); \
}

void pfc_init(void)
{
#if 1   // reference koelch borad setting
	SetGuardREG(PFC_MOD_SEL,  0x60000000);
	SetGuardREG(PFC_MOD_SEL2, 0x40000000);
	SetGuardREG(PFC_MOD_SEL3, 0x00800200);
	SetGuardREG(PFC_MOD_SEL4, 0x00000000);

	SetGuardREG(PFC_IPSR0,    0x00000000);
	SetGuardREG(PFC_IPSR1,    0x00000000);
	SetGuardREG(PFC_IPSR2,    0x000244C8);
	SetGuardREG(PFC_IPSR3,    0x00000000);
	SetGuardREG(PFC_IPSR4,    0x00002400);
	SetGuardREG(PFC_IPSR5,    0x01520000);
	SetGuardREG(PFC_IPSR6,    0x00724003);
	SetGuardREG(PFC_IPSR7,    0x00000000);
	SetGuardREG(PFC_IPSR8,    0x00000000);
	SetGuardREG(PFC_IPSR9,    0x00000000);
	SetGuardREG(PFC_IPSR10,   0x60000000);
	SetGuardREG(PFC_IPSR11,   0x00000003);
	SetGuardREG(PFC_IPSR12,   0x00000000);
	SetGuardREG(PFC_IPSR13,   0x00000000);
	SetGuardREG(PFC_IPSR14,   0x00000000);
	SetGuardREG(PFC_IPSR15,   0x00000000);
	SetGuardREG(PFC_IPSR16,   0x00000000);

	SetGuardREG(PFC_GPSR0,    0xFFFFFFFF);
	SetGuardREG(PFC_GPSR1,    0x00EC3FFF);
	SetGuardREG(PFC_GPSR2,    0x3BC001E7);
	SetGuardREG(PFC_GPSR3,    0x5BFFFFFF);
	SetGuardREG(PFC_GPSR4,    0x1FFFFFFB);
	SetGuardREG(PFC_GPSR5,    0x01BFFFF0);
	SetGuardREG(PFC_GPSR6,    0xCF7FFFFF);
	SetGuardREG(PFC_GPSR7,    0x0381FC00);

	writel(0xFFFFFFDF , PFC_PUPR0);
	writel(0xC883C3FF , PFC_PUPR1);
	writel(0x1201F3C9 , PFC_PUPR2);
	writel(0x00000000 , PFC_PUPR3);
	writel(0xFFFFEB04 , PFC_PUPR4);
	writel(0xC003FFFF , PFC_PUPR5);
	writel(0x0800000F , PFC_PUPR6);
	writel(0x001800F0 , PFC_PUPR7);
#endif
}

void gpio_setting(void)
{
#if 1  // reference koelch borad setting
	writel(0x00000000, GPIO_POSNEG(1));
	writel(0x00000000, GPIO_POSNEG(2));
	writel(0x00000000, GPIO_POSNEG(3));
	writel(0x00000000, GPIO_POSNEG(4));
	writel(0x00000000, GPIO_POSNEG(5));
	writel(0x00000000, GPIO_POSNEG(6));
	writel(0x00000000, GPIO_POSNEG(7));

	writel(0x00000000, GPIO_IOINTSEL(1));
	writel(0x00000000, GPIO_IOINTSEL(2));
	writel(0x00000000, GPIO_IOINTSEL(3));
	writel(0x00000000, GPIO_IOINTSEL(4));
	writel(0x00000000, GPIO_IOINTSEL(5));
	writel(0x00000000, GPIO_IOINTSEL(6));
	writel(0x00000000, GPIO_IOINTSEL(7));

	writel(0x04381000, GPIO_OUTDT(2));
	writel(0x00000000, GPIO_OUTDT(5));
	writel(0x000E0000, GPIO_OUTDT(7));

	writel(0x00000000, GPIO_INOUTSEL(1));
	writel(0x04381010, GPIO_INOUTSEL(2));
	writel(0x00000000, GPIO_INOUTSEL(3));
	writel(0x00000000, GPIO_INOUTSEL(4));
	writel(0x00400000, GPIO_INOUTSEL(5));
	writel(0x00000000, GPIO_INOUTSEL(6));
	writel(0x000E0380, GPIO_INOUTSEL(7));
#endif
}

void lbsc_init(void)
{
#if 1 // reference koelch borad setting
	writel(0x00000020, LBSC_CS0CTRL);
	writel(0x00000020, LBSC_CS1CTRL);
	writel(0x00002020, LBSC_ECS0CTRL);
	writel(0x00002020, LBSC_ECS1CTRL);

	writel(0x2A103320, LBSC_CSWCR0);	//# KOELSCH			//KOELSCH_SPI Ver0.02
	writel(0x2A103320, LBSC_CSWCR1);	//# KOELSCH			//KOELSCH_SPI Ver0.02
	writel(0xFF70FF70, LBSC_ECSWCR0);
	writel(0xFF70FF70, LBSC_ECSWCR1);

	writel(0x00000000, LBSC_CSPWCR0);
	writel(0x00000000, LBSC_CSPWCR1);
	writel(0x00000000, LBSC_ECSPWCR0);
	writel(0x00000000, LBSC_ECSPWCR1);
	writel(0x00000000, LBSC_EXWTSYNC);

	writel(0x00000000, LBSC_CS1GDST);
	writel(0x00000000, LBSC_ECS0GDST);
	writel(0x00000000, LBSC_ECS1GDST);
	writel(0x00000000, LBSC_ATACSCTRL);
#endif
}

void clock_init(void)
{
	/* CPG => module standby and software reset */
	u32 val;

	/* SCIF0 */
	val = readl(MSTPSR7);
	val &= ~SCIF0_MSTP721;
	writel(val, SMSTPCR7);
}

void ddr_init(void)
{
	int cnt=0;
	for(cnt=0; cnt<100000; cnt++);

	writel( 0x21000000 , DBSC3_0_DBCMD);
	writel( 0x21000000 , DBSC3_1_DBCMD);

	writel( 0x11000000 , DBSC3_0_DBCMD);
	writel( 0x11000000 , DBSC3_1_DBCMD);

	writel( 0x10000000 , DBSC3_0_DBCMD);
	writel( 0x10000000 , DBSC3_1_DBCMD);

	writel( 0x0000A55A , DBSC3_0_DBPDLCK);
	writel( 0x0000A55A , DBSC3_1_DBPDLCK);

	writel( 0x00000010 , DBSC3_0_DBPDRGA);
	writel( 0x00000010 , DBSC3_1_DBPDRGA);

	writel( 0xF004649B , DBSC3_0_DBPDRGD);
	writel( 0xF004649B , DBSC3_1_DBPDRGD);

	writel( 0x00000007 , DBSC3_0_DBKIND);
	writel( 0x00000007 , DBSC3_1_DBKIND);

	writel( 0x0F030A02 , DBSC3_0_DBCONF0);
	writel( 0x0F030A02 , DBSC3_1_DBCONF0);

	writel( 0x00000001 , DBSC3_0_PHYT);
	writel( 0x00000001 , DBSC3_1_PHYT);

	writel( 0x00000000 , DBSC3_0_DBBL);
	writel( 0x00000000 , DBSC3_1_DBBL);

	writel( 0x0000000B , DBSC3_0_DBTR0);
	writel( 0x0000000B , DBSC3_1_DBTR0);

	writel( 0x00000008 , DBSC3_0_DBTR1);
	writel( 0x00000008 , DBSC3_1_DBTR1);

	writel( 0x00000000 , DBSC3_0_DBTR2);
	writel( 0x00000000 , DBSC3_1_DBTR2);

	writel( 0x0000000B , DBSC3_0_DBTR3);
	writel( 0x0000000B , DBSC3_1_DBTR3);

	writel( 0x000C000B , DBSC3_0_DBTR4);
	writel( 0x000C000B , DBSC3_1_DBTR4);

	writel( 0x00000027 , DBSC3_0_DBTR5);
	writel( 0x00000027 , DBSC3_1_DBTR5);

	writel( 0x0000001C , DBSC3_0_DBTR6);
	writel( 0x0000001C , DBSC3_1_DBTR6);

	writel( 0x00000006 , DBSC3_0_DBTR7);
	writel( 0x00000006 , DBSC3_1_DBTR7);

	writel( 0x00000020 , DBSC3_0_DBTR8);
	writel( 0x00000020 , DBSC3_1_DBTR8);

	writel( 0x00000008 , DBSC3_0_DBTR9);
	writel( 0x00000008 , DBSC3_1_DBTR9);

	writel( 0x0000000C , DBSC3_0_DBTR10);
	writel( 0x0000000C , DBSC3_1_DBTR10);

	writel( 0x00000009 , DBSC3_0_DBTR11);
	writel( 0x00000009 , DBSC3_1_DBTR11);

	writel( 0x00000012 , DBSC3_0_DBTR12);
	writel( 0x00000012 , DBSC3_1_DBTR12);

	writel( 0x000000D0 , DBSC3_0_DBTR13);
	writel( 0x000000D0 , DBSC3_1_DBTR13);

	writel( 0x00140005 , DBSC3_0_DBTR14);
	writel( 0x00140005 , DBSC3_1_DBTR14);

	writel( 0x00050004 , DBSC3_0_DBTR15);
	writel( 0x00050004 , DBSC3_1_DBTR15);

	writel( 0x70233005 , DBSC3_0_DBTR16);
	writel( 0x70233005 , DBSC3_1_DBTR16);

	writel( 0x000C0000 , DBSC3_0_DBTR17);
	writel( 0x000C0000 , DBSC3_1_DBTR17);

	writel( 0x00000300 , DBSC3_0_DBTR18);
	writel( 0x00000300 , DBSC3_1_DBTR18);

	writel( 0x00000040 , DBSC3_0_DBTR19);
	writel( 0x00000040 , DBSC3_1_DBTR19);

	writel( 0x00000001 , DBSC3_0_DBRNK0);
	writel( 0x00000001 , DBSC3_1_DBRNK0);

	writel( 0x00020001 , DBSC3_0_DBADJ0);
	writel( 0x00020001 , DBSC3_1_DBADJ0);

	writel( 0x20082008 , DBSC3_0_DBADJ2);
	writel( 0x20082008 , DBSC3_1_DBADJ2);

	writel( 0x00020002 , DBSC3_0_DBWT0CNF0);
	writel( 0x00020002 , DBSC3_1_DBWT0CNF0);

	writel( 0x0000001F , DBSC3_0_DBWT0CNF4);
	writel( 0x0000001F , DBSC3_1_DBWT0CNF4);

	while( 1 != (readl(DBSC3_0_DBDFISTAT) & 0x1) );
	while( 1 != (readl(DBSC3_1_DBDFISTAT) & 0x1) );

	writel( 0x00000011 , DBSC3_0_DBDFICNT);
	writel( 0x00000011 , DBSC3_1_DBDFICNT);

	writel( 0x00000006 , DBSC3_0_DBPDRGA);
	writel( 0x00000006 , DBSC3_1_DBPDRGA);

	writel( 0x0001C000 , DBSC3_0_DBPDRGD);
	writel( 0x0001C000 , DBSC3_1_DBPDRGD);

	writel( 0x00000003 , DBSC3_0_DBPDRGA);
	writel( 0x00000003 , DBSC3_1_DBPDRGA);

	writel( 0x0300C481 , DBSC3_0_DBPDRGD);
	writel( 0x0300C481 , DBSC3_1_DBPDRGD);

	writel( 0x00000023 , DBSC3_0_DBPDRGA);
	writel( 0x00000023 , DBSC3_1_DBPDRGA);

	writel( 0x00FDB6C0 , DBSC3_0_DBPDRGD);
	writel( 0x00FDB6C0 , DBSC3_1_DBPDRGD);

	writel( 0x00000011 , DBSC3_0_DBPDRGA);
	writel( 0x00000011 , DBSC3_1_DBPDRGA);

	writel( 0x1000040B , DBSC3_0_DBPDRGD);
	writel( 0x1000040B , DBSC3_1_DBPDRGD);

	writel( 0x00000012 , DBSC3_0_DBPDRGA);
	writel( 0x00000012 , DBSC3_1_DBPDRGA);

	writel( 0x9D9CBB66 , DBSC3_0_DBPDRGD);
	writel( 0x9D9CBB66 , DBSC3_1_DBPDRGD);

	writel( 0x00000013 , DBSC3_0_DBPDRGA);
	writel( 0x00000013 , DBSC3_1_DBPDRGA);

	writel( 0x1A868400 , DBSC3_0_DBPDRGD);
	writel( 0x1A868400 , DBSC3_1_DBPDRGD);

	writel( 0x00000014 , DBSC3_0_DBPDRGA);
	writel( 0x00000014 , DBSC3_1_DBPDRGA);

	writel( 0x300214D8 , DBSC3_0_DBPDRGD);
	writel( 0x300214D8 , DBSC3_1_DBPDRGD);

	writel( 0x00000015 , DBSC3_0_DBPDRGA);
	writel( 0x00000015 , DBSC3_1_DBPDRGA);

	writel( 0x00000D70 , DBSC3_0_DBPDRGD);
	writel( 0x00000D70 , DBSC3_1_DBPDRGD);

	writel( 0x00000016 , DBSC3_0_DBPDRGA);
	writel( 0x00000016 , DBSC3_1_DBPDRGA);

	writel( 0x00000006 , DBSC3_0_DBPDRGD);
	writel( 0x00000006 , DBSC3_1_DBPDRGD);

	writel( 0x00000017 , DBSC3_0_DBPDRGA);
	writel( 0x00000017 , DBSC3_1_DBPDRGA);

	writel( 0x00000018 , DBSC3_0_DBPDRGD);
	writel( 0x00000018 , DBSC3_1_DBPDRGD);

	writel( 0x0000001A , DBSC3_0_DBPDRGA);
	writel( 0x0000001A , DBSC3_1_DBPDRGA);

	writel( 0x910035C7 , DBSC3_0_DBPDRGD);
	writel( 0x910035C7 , DBSC3_1_DBPDRGD);

	writel( 0x00000004 , DBSC3_0_DBPDRGA);
	writel( 0x00000004 , DBSC3_1_DBPDRGA);

	while( 1 != (readl(DBSC3_0_DBPDRGD)&0x1) );
	while( 1 != (readl(DBSC3_1_DBPDRGD)&0x1) );

	writel( 0x00000001 , DBSC3_0_DBPDRGA);
	writel( 0x00000001 , DBSC3_1_DBPDRGA);

	writel( 0x00000181 , DBSC3_0_DBPDRGD);
	writel( 0x00000181 , DBSC3_1_DBPDRGD);

	writel( 0x11000000 , DBSC3_0_DBCMD);
	writel( 0x11000000 , DBSC3_1_DBCMD);

	writel( 0x00000004 , DBSC3_0_DBPDRGA);
	writel( 0x00000004 , DBSC3_1_DBPDRGA);

	while( 1 != (readl(DBSC3_0_DBPDRGD)&0x1) );
	while( 1 != (readl(DBSC3_1_DBPDRGD)&0x1) );

	writel( 0x00000001 , DBSC3_0_DBPDRGA);
	writel( 0x00000001 , DBSC3_1_DBPDRGA);

	writel( 0x0000FE01 , DBSC3_0_DBPDRGD);
	writel( 0x0000FE01 , DBSC3_1_DBPDRGD);

	writel( 0x00000004 , DBSC3_0_DBPDRGA);
	writel( 0x00000004 , DBSC3_1_DBPDRGA);

	while( 1 != (readl(DBSC3_0_DBPDRGD)&0x1) );
	while( 1 != (readl(DBSC3_1_DBPDRGD)&0x1) );

	writel( 0x00000000 , DBSC3_0_DBBS0CNT1);
	writel( 0x00000000 , DBSC3_1_DBBS0CNT1);

	writel( 0x01004C20 , DBSC3_0_DBCALCNF);
	writel( 0x01004C20 , DBSC3_1_DBCALCNF);

	writel( 0x014000AA , DBSC3_0_DBCALTR);
	writel( 0x014000AA , DBSC3_1_DBCALTR);

	writel( 0x00000140 , DBSC3_0_DBRFCNF0);
	writel( 0x00000140 , DBSC3_1_DBRFCNF0);

	writel( 0x00081860 , DBSC3_0_DBRFCNF1);
	writel( 0x00081860 , DBSC3_1_DBRFCNF1);

	writel( 0x00010000 , DBSC3_0_DBRFCNF2);
	writel( 0x00010000 , DBSC3_1_DBRFCNF2);

	writel( 0x00000001 , DBSC3_0_DBRFEN);
	writel( 0x00000001 , DBSC3_1_DBRFEN);

	writel( 0x00000001 , DBSC3_0_DBACEN);
	writel( 0x00000001 , DBSC3_1_DBACEN);

	writel( 0x00000000 , DBSC3_0_DBPDLCK);
	writel( 0x00000000 , DBSC3_1_DBPDLCK);

	writel( 0x0000000C , 0xE678400C); //S3CTRL_S3CMAAR
}

#define SCIF0_BASE		0xe6e60000
#define SCIF1_BASE		0xe6e68000
#define PORT_SCI	52
#define PORT_SCIF	53
#define PORT_SCIFA	83
#define PORT_SCIFB	93
void board_init(void)
{
	wtd_init();
	pfc_init();
	gpio_setting();
	lbsc_init();
	ddr_init();

	clock_init();
	uart_init(SCIF0_BASE, PORT_SCIF);
}

void boot_main(void)
{
#define CONFIG_UBOOT_OFFSET    	0x20000
#define CONFIG_UBOOT_LOADADDR	0xe6304000
#define LOAD_UBOOT_SIZE			(200*1024)
	board_init();

	print("\nMiniboot Version --0.2\n");

#if 1
	// for loader uboot and run
	print("Load uboot %dKB from spi offset %x to %x\n",LOAD_UBOOT_SIZE/1024, CONFIG_UBOOT_OFFSET, CONFIG_UBOOT_LOADADDR);
	QSPI_Initialize();
	QSPI_QuadRead_Flash(CONFIG_UBOOT_OFFSET, LOAD_UBOOT_SIZE, (void*)CONFIG_UBOOT_LOADADDR, true);
	QSPI_DeInitialize();
	print("Read ok\n");
	(*((void(*)(void))CONFIG_UBOOT_LOADADDR))();
#endif

#if 0 // for write miniboot
	memset((void*)0xe6304000, 0xff, 0x4000);

	QSPI_Initialize();
	print("miniboot: erase 0-0x10000, 64KB\n");
	QSPI_BlockErase_Flash(0, 0x10000);
	QSPI_QuadRead_Flash(0, 0x4000, (void *)0xe6304000, true);

	print("load miniboot 16KB to 0xe6304000, please enter 'm' to continue\n");
	while('m'!=sh_serial_getc()) udelay(100);

	print("write miniboot\n");
	QSPI_Write_Flash(0, 0x4000, (void *)0xe6304000);
	print("write miniboot finished\n");

	QSPI_QuadRead_Flash(0, 0x4000, (void *)0xe6304000, true);
	QSPI_DeInitialize();
#endif

#if 0 // for write uboot
	memset((void*)0xe6304000, 0xff, 0x32000);

	QSPI_Initialize();
	print("uboot: erase 0x20000-0x60000, 256KB\n");
	QSPI_BlockErase_Flash(0x20000, 0x40000);
	QSPI_QuadRead_Flash(0x20000, 0x32000, (void *)0xe6304000, true);

	print("load uboot 200KB to 0xe6304000, please enter 'u' to continue\n");
	while('u'!=sh_serial_getc()) udelay(100);

	print("write uboot\n");
	QSPI_Write_Flash(0x20000, 0x32000, (void *)0xe6304000);
	print("write uboot finished\n");

	QSPI_QuadRead_Flash(0x20000, 0x32000, (void *)0xe6304000, true);
	QSPI_DeInitialize();
#endif

	return;
}
