#include "board.h"

static void wtd_init(void)
{
	/* RWDT,secureWDT setting (Timer Disable setting) */
	writel(0xA5A5A500, RWTCSRA);
	writel(0xA5A5A500, SWTCSRA);
}

#define GENERIC_TIMER 0xe6080000U
#define CNTCR         0x0U
#define CNTFID0       0x20U
static void InitTimer(void)
{
	unsigned long freq = 260000000 / 8 ;/* ZS / 8 */
	/* set freq */
	*((volatile unsigned long*)(GENERIC_TIMER + CNTFID0)) = freq;
	asm volatile("mcr p15, 0, %0, c14, c0, 0" : : "r"(freq));
	/* timer start */
	*((volatile unsigned long*)(GENERIC_TIMER + CNTCR)) = 1;
}

#define	SetGuardREG_back(addr, mask, value)		\
{ \
	u32	val; \
	val = (readl(addr) & ~(mask)) | (value);	\
	writel(~val, PFC_PMMR); \
	writel(val, addr); \
}

#define	SetGuardREG(addr, value)		\
{ \
	writel(~value, PFC_PMMR); \
	writel(value, addr); \
}

static void pfc_init(void)
{
#if 1   // reference alt borad setting
	SetGuardREG(PFC_MOD_SEL,  0x00000000);
	SetGuardREG(PFC_MOD_SEL2, 0x00000000);
	SetGuardREG(PFC_MOD_SEL3, 0x20000000);

	SetGuardREG(PFC_IPSR0,    0x00000000);
	SetGuardREG(PFC_IPSR1,    0x00005000);
	SetGuardREG(PFC_IPSR2,    0x40000000);
	SetGuardREG(PFC_IPSR3,    0x00000155);
	SetGuardREG(PFC_IPSR4,    0x00000002);
	SetGuardREG(PFC_IPSR5,    0x00000000);
	SetGuardREG(PFC_IPSR6,    0x00000003);
	SetGuardREG(PFC_IPSR7,    0x00000000);
	SetGuardREG(PFC_IPSR8,    0x60000000);
	SetGuardREG(PFC_IPSR9,    0x36DAB6DB);
	SetGuardREG(PFC_IPSR10,   0x926DA012);
	SetGuardREG(PFC_IPSR11,   0x0008C383);
	SetGuardREG(PFC_IPSR12,   0x00000000);
	SetGuardREG(PFC_IPSR13,   0x00000140);

	SetGuardREG(PFC_GPSR0,    0xFFFFFFFF);
	SetGuardREG(PFC_GPSR1,    0x00EC3FFF);
	SetGuardREG(PFC_GPSR2,    0x5BFFFFFF);
	SetGuardREG(PFC_GPSR3,    0x01BFE1FF);
	SetGuardREG(PFC_GPSR4,    0x5BFFFFFF);
	SetGuardREG(PFC_GPSR5,    0x0F4B200F);
	SetGuardREG(PFC_GPSR6,    0x03FFFFFF);

	writel(0x00000000 , PFC_PUPR0);
	writel(0x4203FC00 , PFC_PUPR1);
	writel(0x00000000 , PFC_PUPR2);
	writel(0x159007FF , PFC_PUPR3);
	writel(0x80000000 , PFC_PUPR4);
	writel(0x00DE481F , PFC_PUPR5);
	writel(0x00000000 , PFC_PUPR6);

	SetGuardREG(PFC_IOCTRL0,    0xFFFFFFFF);
    SetGuardREG(PFC_IOCTRL1,    0xFFFFF000);
    SetGuardREG(PFC_IOCTRL2,    0x55555500);
    SetGuardREG(PFC_IOCTRL3,    0xFFFFFF00);
    SetGuardREG(PFC_IOCTRL7,    0x00000000);
#endif
}

static void gpio_setting(void)
{
#if 1 // reference alt borad setting
    writel(0x00000000, GPIO_POSNEG(1));
	writel(0x00000000, GPIO_POSNEG(2));
	writel(0x00000000, GPIO_POSNEG(3));
	writel(0x00000000, GPIO_POSNEG(4));
	writel(0x00000000, GPIO_POSNEG(5));

    writel(0x00000000, GPIO_IOINTSEL(1));
	writel(0x00000000, GPIO_IOINTSEL(2));
	writel(0x00000000, GPIO_IOINTSEL(3));
	writel(0x00000000, GPIO_IOINTSEL(4));
	writel(0x00000000, GPIO_IOINTSEL(5));

    writel(0x24000000, GPIO_OUTDT(2));
	writel(0xA4002000, GPIO_OUTDT(4));
	writel(0x0004C000, GPIO_OUTDT(5));

	writel(0x01000000, GPIO_INOUTSEL(1));
	writel(0x24000000, GPIO_INOUTSEL(2));
	writel(0x00000000, GPIO_INOUTSEL(3));
	writel(0xA4002000, GPIO_INOUTSEL(4));
	writel(0x0084C380, GPIO_INOUTSEL(5));
#endif
}

static void lbsc_init(void)
{
#if 1 // reference alt borad setting
    writel(0x00000020, LBSC_CS0CTRL);
	writel(0x00000020, LBSC_CS1CTRL);
	writel(0x00002020, LBSC_ECS0CTRL);
	writel(0x00002020, LBSC_ECS1CTRL);

	writel(0x2A103320, LBSC_CSWCR0);
	writel(0x2A103320, LBSC_CSWCR1);
	writel(0xFF70FF70, LBSC_ECSWCR0);
	writel(0xFF70FF70, LBSC_ECSWCR1);

	writel(0x00000000, LBSC_CSPWCR0);
	writel(0x00000000, LBSC_CSPWCR1);
	writel(0x00000000, LBSC_ECSPWCR0);
	writel(0x00000000, LBSC_ECSPWCR1);
	writel(0x00000000, LBSC_EXWTSYNC);

	writel(0x00000000, LBSC_CS1GDST);
	writel(0x00000000, LBSC_ECS0GDST);
	writel(0x00000000, LBSC_ECS1GDST);
#endif
}

static void clock_init(void)
{
#if 0
enum {
	MSTP00, MSTP01, MSTP02, MSTP03, MSTP04, MSTP05,
	MSTP07, MSTP08, MSTP09, MSTP10, MSTP11,
	MSTP_NR
};

	int i = 0;
	struct mstp_ctl {
		u32 s_addr;
		u32 s_ena;
		u32 r_addr;
		u32 r_ena;
	} mstptbl[MSTP_NR] = {
		[MSTP00] = { SMSTPCR0,  0x00000000U, RMSTPCR0,  0x00000000U, },
		[MSTP01] = { SMSTPCR1,  0x6C976625U, RMSTPCR1,  0x6C976625U, },
		[MSTP02] = { SMSTPCR2,  0x00000000U, RMSTPCR2,  0x00000000U, },
		[MSTP03] = { SMSTPCR3,  0x1F7B27EFU, RMSTPCR3,  0x1F7B27EFU, },
		[MSTP04] = { SMSTPCR4,  0x00000000U, RMSTPCR4,  0x00000000U, },
		[MSTP05] = { SMSTPCR5,  0x8320BFBBU, RMSTPCR5,  0x8320BFBBU, },
		[MSTP07] = { SMSTPCR7,  0xFEC019C7U, RMSTPCR7,  0xFEC019C7U, },
		[MSTP08] = { SMSTPCR8,  0x0170C380U, RMSTPCR8,  0x0170C380U, },
		[MSTP09] = { SMSTPCR9,  0x00506001U, RMSTPCR9,  0x00506001U, },
		[MSTP10] = { SMSTPCR10, 0xFFFEDFE0U, RMSTPCR10, 0xFFFEDFE0U, },
		[MSTP11] = { SMSTPCR11, 0x00000037U, RMSTPCR11, 0x00000037U, },
	};

	for (i = MSTP00; i < MSTP_NR; i++) {
		writel(mstptbl[i].s_ena, mstptbl[i].s_addr);
		writel(mstptbl[i].r_ena, mstptbl[i].r_addr);
	}
#else
	/* CPG => module standby and software reset */
	u32 val;

	/* SCIF1 */
	val = readl(MSTPSR7);
	val &= ~SCIF1_MSTP720;
	writel(val, SMSTPCR7);
#endif
}

void ddr_init(void)
{
	writel( 0x21000000 , DBSC3_0_DBCMD);
	writel( 0x11000000 , DBSC3_0_DBCMD);
	writel( 0x10000000 , DBSC3_0_DBCMD);
	writel( 0x0000A55A , DBSC3_0_DBPDLCK);
	writel( 0x00000001 , DBSC3_0_DBPDRGA);
	writel( 0x80000000 , DBSC3_0_DBPDRGD);
    writel( 0x00000004 , DBSC3_0_DBPDRGA);

    while( 1 != (readl(DBSC3_0_DBPDRGD) & 0x1) );

    writel( 0x00000006 , DBSC3_0_DBPDRGA);
    writel( 0x0005C000 , DBSC3_0_DBPDRGD);
    writel( 0x00000010 , DBSC3_0_DBPDRGA);
    writel( 0xF00464DB , DBSC3_0_DBPDRGD);
    writel( 0x00000061 , DBSC3_0_DBPDRGA);
    writel( 0x0000006D , DBSC3_0_DBPDRGD);
    writel( 0x00000001 , DBSC3_0_DBPDRGA);
    writel( 0x00000073 , DBSC3_0_DBPDRGD);
    writel( 0x00000007 , DBSC3_0_DBKIND);
    writel( 0x0F030A02 , DBSC3_0_DBCONF0);
    writel( 0x00000001 , DBSC3_0_PHYT);
    writel( 0x00000000 , DBSC3_0_DBBL);
    writel( 0x00000009 , DBSC3_0_DBTR0);
    writel( 0x00000007 , DBSC3_0_DBTR1);
    writel( 0x00000000 , DBSC3_0_DBTR2);
    writel( 0x00000009 , DBSC3_0_DBTR3);
    writel( 0x000A0009 , DBSC3_0_DBTR4);
    writel( 0x00000021 , DBSC3_0_DBTR5);
    writel( 0x00000018 , DBSC3_0_DBTR6);
    writel( 0x00000005 , DBSC3_0_DBTR7);
    writel( 0x0000001B , DBSC3_0_DBTR8);
    writel( 0x00000007 , DBSC3_0_DBTR9);
    writel( 0x0000000A , DBSC3_0_DBTR10);
    writel( 0x00000009 , DBSC3_0_DBTR11);
    writel( 0x00000010 , DBSC3_0_DBTR12);
    writel( 0x000000AE , DBSC3_0_DBTR13);
    writel( 0x00140005 , DBSC3_0_DBTR14);
    writel( 0x00050004 , DBSC3_0_DBTR15);
    writel( 0x50213005 , DBSC3_0_DBTR16);
    writel( 0x000C0000 , DBSC3_0_DBTR17);
    writel( 0x00000200 , DBSC3_0_DBTR18);
    writel( 0x00000040 , DBSC3_0_DBTR19);
    writel( 0x00000001 , DBSC3_0_DBRNK0);
    writel( 0x00020001 , DBSC3_0_DBADJ0);
    writel( 0x20082008 , DBSC3_0_DBADJ2);
    writel( 0x00020003 , DBSC3_0_DBWT0CNF0);
    writel( 0x0000001F , DBSC3_0_DBWT0CNF4);

    while( 1 != (readl(DBSC3_0_DBDFISTAT) & 0x1) );

    writel( 0x00000011 , DBSC3_0_DBDFICNT);
    writel( 0x00000003 , DBSC3_0_DBPDRGA);
    writel( 0x0300C4E1 , DBSC3_0_DBPDRGD);
    writel( 0x00000023 , DBSC3_0_DBPDRGA);
    writel( 0x00FCB6D0 , DBSC3_0_DBPDRGD);
    writel( 0x00000011 , DBSC3_0_DBPDRGA);
    writel( 0x1000040B , DBSC3_0_DBPDRGD);
    writel( 0x00000012 , DBSC3_0_DBPDRGA);
    writel( 0x85589955 , DBSC3_0_DBPDRGD);
    writel( 0x00000013 , DBSC3_0_DBPDRGA);
    writel( 0x1A852400 , DBSC3_0_DBPDRGD);
    writel( 0x00000014 , DBSC3_0_DBPDRGA);
    writel( 0x300210B4 , DBSC3_0_DBPDRGD);
    writel( 0x00000015 , DBSC3_0_DBPDRGA);
    writel( 0x00000B50 , DBSC3_0_DBPDRGD);
    writel( 0x00000016 , DBSC3_0_DBPDRGA);
    writel( 0x00000006 , DBSC3_0_DBPDRGD);
    writel( 0x00000017 , DBSC3_0_DBPDRGA);
    writel( 0x00000010 , DBSC3_0_DBPDRGD);
    writel( 0x0000001A , DBSC3_0_DBPDRGA);
    writel( 0x910035C7 , DBSC3_0_DBPDRGD);
    writel( 0x00000004 , DBSC3_0_DBPDRGA);

    while( 1 != (readl(DBSC3_0_DBPDRGD)&0x1) );

    writel( 0x00000001 , DBSC3_0_DBPDRGA);
    writel( 0x00000181 , DBSC3_0_DBPDRGD);
    writel( 0x11000000 , DBSC3_0_DBCMD);
    writel( 0x00000004 , DBSC3_0_DBPDRGA);

    while( 1 != (readl(DBSC3_0_DBPDRGD)&0x1) );

    writel( 0x00000001 , DBSC3_0_DBPDRGA);
    writel( 0x0000FE01 , DBSC3_0_DBPDRGD);
    writel( 0x00000000 , DBSC3_0_DBBS0CNT1);
    writel( 0x01004C20 , DBSC3_0_DBCALCNF);
    writel( 0x014000AA , DBSC3_0_DBCALTR);
    writel( 0x00000140 , DBSC3_0_DBRFCNF0);
    writel( 0x00081450 , DBSC3_0_DBRFCNF1);
    writel( 0x00010000 , DBSC3_0_DBRFCNF2);
    writel( 0x00000004 , DBSC3_0_DBPDRGA);

    while( 1 != (readl(DBSC3_0_DBPDRGD)&0x1) );

    writel( 0x00000001 , DBSC3_0_DBRFEN);
    writel( 0x00000001 , DBSC3_0_DBACEN);
    writel( 0x00000000 , DBSC3_0_DBPDLCK);
}

#define SCIF0_BASE	0xe6e60000
#define SCIF1_BASE	0xe6e68000
#define PORT_SCI	52
#define PORT_SCIF	53
#define PORT_SCIFA	83
#define PORT_SCIFB	93
void board_init(void)
{
	wtd_init();
	InitTimer();
	pfc_init();
	gpio_setting();
	lbsc_init();
	ddr_init();
	clock_init();
	uart_init(SCIF1_BASE, PORT_SCIF);
}

// mode select update bootloader or load bootloader
#define IS_WRITE_SPINOR (readl(GPIO_INDT(1)) & BIT25)	//gpio_1_25

void boot_main(void)
{
#define CONFIG_UBOOT_OFFSET    	0x20000
#define CONFIG_UBOOT_LOADADDR	0xe6304000
#define LOAD_UBOOT_SIZE			(200*1024)
#define SREC_DATA_ADDR			0x40000000
	board_init();

	print("\nMiniboot Version --0.2\n");

#if 1
	if(IS_WRITE_SPINOR) {
		char c;
		unsigned long srec_size = 0;

		while(1) {
			print("--------------------------\n");
			print("|-input '1' write miniboot\n");
			print("|-input '2' write u-boot\n");
			print("|-input '3' write kernel\n");
			print("--------------------------\n");

			c = sh_serial_getc();
			if (('\n' == c) || ('\r' == c)) {
				continue;
			}

			if ('1' == c) {
				print("Please send miniboot srec file\n");
				srec_size = serial_srec2bin(SREC_DATA_ADDR);
				if (!srec_size) {
					print("write miniboot failed\n");
					continue;
				}
				QSPI_Initialize();
				QSPI_BlockErase_Flash(0, 0x10000);
				QSPI_Write_Flash(0, srec_size, (void *)SREC_DATA_ADDR);
				QSPI_DeInitialize();

				print("write miniboot finished\n");
			}

			if ('2' == c) {
				print("Please send uboot srec file\n");
				srec_size = serial_srec2bin(SREC_DATA_ADDR);
				if (!srec_size) {
					print("write uboot failed\n");
					continue;
				}
				QSPI_Initialize();
				QSPI_BlockErase_Flash(0x20000, 0x40000);
				QSPI_Write_Flash(0x20000, srec_size, (void *)SREC_DATA_ADDR);
				QSPI_DeInitialize();

				print("write uboot finished\n");
			}

			if ('3' == c) {
				print("Please send kernel srec file\n");
				srec_size = serial_srec2bin(SREC_DATA_ADDR);
				if (!srec_size) {
					print("write kernel failed\n");
					continue;
				}
				QSPI_Initialize();
				QSPI_BlockErase_Flash(0x100000, 0x400000);
				QSPI_Write_Flash(0x100000, srec_size, (void *)SREC_DATA_ADDR);
				QSPI_DeInitialize();

				print("write kernel finished\n");
			}

			if ('b' == c) {
				break;
			}
		}

	}

	// for loader uboot and run
	print("Load uboot %dKB from spi offset %x to %x\n",LOAD_UBOOT_SIZE/1024, CONFIG_UBOOT_OFFSET, CONFIG_UBOOT_LOADADDR);
	QSPI_Initialize();
	//QSPI_QuadRead_Flash(CONFIG_UBOOT_OFFSET, LOAD_UBOOT_SIZE, (void*)CONFIG_UBOOT_LOADADDR, true);
	QSPI_DMA_READ(CONFIG_UBOOT_OFFSET, CONFIG_UBOOT_LOADADDR, LOAD_UBOOT_SIZE);
	QSPI_DeInitialize();
	print("Read ok\n");
	(*((void(*)(void))CONFIG_UBOOT_LOADADDR))();
#endif

#if 0 // for write miniboot
	memset((void*)0xe6304000, 0xff, 0x4000);

	QSPI_Initialize();
	print("miniboot: erase 0-0x10000, 64KB\n");
	QSPI_BlockErase_Flash(0, 0x10000);
	QSPI_QuadRead_Flash(0, 0x4000, (void *)0xe6304000, true);

	print("load miniboot 16KB to 0xe6304000, please enter 'm' to continue\n");
	while('m'!=sh_serial_getc()) udelay(100);

	print("write miniboot\n");
	QSPI_Write_Flash(0, 0x4000, (void *)0xe6304000);
	print("write miniboot finished\n");

	QSPI_QuadRead_Flash(0, 0x4000, (void *)0xe6304000, true);
	QSPI_DeInitialize();
#endif

#if 0 // for write uboot
	memset((void*)0xe6304000, 0xff, 0x32000);

	QSPI_Initialize();
	print("uboot: erase 0x20000-0x60000, 256KB\n");
	QSPI_BlockErase_Flash(0x20000, 0x40000);
	QSPI_QuadRead_Flash(0x20000, 0x32000, (void *)0xe6304000, true);

	print("load uboot 200KB to 0xe6304000, please enter 'u' to continue\n");
	while('u'!=sh_serial_getc()) udelay(100);

	print("write uboot\n");
	QSPI_Write_Flash(0x20000, 0x32000, (void *)0xe6304000);
	print("write uboot finished\n");

	QSPI_QuadRead_Flash(0x20000, 0x32000, (void *)0xe6304000, true);
	QSPI_DeInitialize();
#endif

#if 0 // for test
	QSPI_Initialize();

	print("test spi-norflash erase and read address=1M size=64KB\n");
	QSPI_BlockErase_Flash(0x100000, 0x10000);
	QSPI_QuadRead_Flash(0x100000, 0x10000, (void *)0xe6304000, false);

	print("erase complete, check 0xe6304000 address then please enter 't' to continue\n");
	while('t'!=sh_serial_getc()) udelay(100);

	print("test spi-norflash write and read address=1M size=64KB, value=0x11\n");
	memset((void*)0xe6314000, 0xa5, 0x10000);
	QSPI_Write_Flash(0x100000, 0x10000, (void*)0xe6314000);
	QSPI_QuadRead_Flash(0x100000, 0x10000, (void *)0xe6304000, true);

	QSPI_DeInitialize();
#endif

	return;
}
